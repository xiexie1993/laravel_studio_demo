<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class CurlController extends Controller
{
    //
    //xzb@17:24 2017/5/28 Start
    //GET - 从指定的资源请求数据。
    public function getrequest()
    {
        //get请求地址
        $url = "http://192.168.10.109:8012/select_info";
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);    // 要求结果为字符串且输出到屏幕上
        curl_setopt($ch, CURLOPT_HEADER, 0); // 不要http header 加快效率
        curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (compatible; MSIE 5.01; Windows NT 5.0)');
        curl_setopt($ch, CURLOPT_TIMEOUT, 15);
        $output = curl_exec($ch);
        //关闭curl
        curl_close($ch);
        
        //打印返回结果
        var_dump($output);
    
    }
    //xzb@17:24 2017/5/28 The End
    
    //xzb@17:30 2017/5/28 Start
    //POST - 向指定的资源提交要被处理的数据
    public function postrequest()
    {
        //post请求地址
        $url = "http://192.168.10.109:8012/testcurl";
        
        //POST数据
        $post_data = array (
            "d" => 1
        );
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
         
        // 我们在POST数据哦！
        curl_setopt($ch, CURLOPT_POST, 1);
         
        // 把post的变量加上
        curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);
         
        $output = curl_exec($ch);
        curl_close($ch);
        
        //打印返回结果
        echo $output;
    }
}
