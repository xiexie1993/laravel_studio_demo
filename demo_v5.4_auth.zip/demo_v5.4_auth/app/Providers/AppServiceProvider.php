<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
//xzb@20:31 2017/5/27 Start
use Illuminate\Support\Facades\Schema; //Import Schema
//xzb@20:31 2017/5/27 The End

class AppServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        //
		//xzb@20:31 2017/5/27 Start
		Schema::defaultStringLength(191); //Solved by increasing StringLength
		//xzb@20:31 2017/5/27 The End
    }

    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }
}
